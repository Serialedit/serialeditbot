
import os
import asyncio
from moviepy.editor import *
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes

# ==== CONFIG ====
TOKEN = "PASTE_YOUR_BOT_TOKEN_HERE"
SERIAL_POS = (234, 0)  # x, y for overlay
SERIAL_SIZE = (512, 420)
TARGET_DURATION = 21 * 60  # 21 minutes in seconds
VOLUME_SETTINGS = {"serial": 1.0, "background": 0.2, "vlog": 0.9}

# ====== Helpers ======
async def process_video(serial_path, vlog_path=None):
    bg_clip = VideoFileClip("background.mp4").without_audio()
    serial_clip = VideoFileClip(serial_path).resize(height=SERIAL_SIZE[1]).fx(vfx.speedx, 1.3)
    serial_clip = serial_clip.set_position(SERIAL_POS).set_audio(serial_clip.audio.volumex(VOLUME_SETTINGS["serial"]))
    bg_loops = int(serial_clip.duration // bg_clip.duration) + 1
    bg_full = concatenate_videoclips([bg_clip] * bg_loops).subclip(0, serial_clip.duration)
    combined = CompositeVideoClip([bg_full, serial_clip])

    if vlog_path:
        vlog_clip = VideoFileClip(vlog_path)
        vlog_duration_needed = TARGET_DURATION - combined.duration
        if vlog_duration_needed > 0:
            vlog_speed = vlog_clip.duration / vlog_duration_needed
            vlog_final = vlog_clip.fx(vfx.speedx, vlog_speed).set_audio(vlog_clip.audio.volumex(VOLUME_SETTINGS["vlog"]))
            final = concatenate_videoclips([combined, vlog_final])
        else:
            final = combined
    else:
        final = combined

    final = final.set_audio(final.audio.volumex(1.0))  # Final master volume
    final.write_videofile("final_output.mp4", fps=24)

# ==== Handlers ====
serial_file = None
vlog_file = None

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Send me your serial (4:3 mp4), then optionally send vlog.mp4. I will generate a final video for you.")

async def handle_video(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global serial_file, vlog_file
    file = await update.message.video.get_file()
    filename = update.message.caption or file.file_path.split("/")[-1]
    path = os.path.join("downloads", filename)
    os.makedirs("downloads", exist_ok=True)
    await file.download_to_drive(path)

    if "serial" in filename.lower():
        serial_file = path
        await update.message.reply_text("✅ Serial video received.")
    elif "vlog" in filename.lower():
        vlog_file = path
        await update.message.reply_text("✅ Vlog video received.")
    else:
        await update.message.reply_text("⚠️ Please name files as 'serial.mp4' or 'vlog.mp4'.")

    if serial_file:
        await update.message.reply_text("⏳ Processing video...")
        await asyncio.to_thread(process_video, serial_file, vlog_file)
        await update.message.reply_video(video=open("final_output.mp4", "rb"))
        serial_file = vlog_file = None

# ==== Main Bot ====
def main():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.VIDEO, handle_video))
    app.run_polling()

if __name__ == "__main__":
    main()
